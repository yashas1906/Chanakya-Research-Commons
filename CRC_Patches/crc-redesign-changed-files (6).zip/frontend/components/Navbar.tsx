"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, Plus, X } from "lucide-react";
import { AccountMenu } from "@/components/shell/AccountMenu";
import { GlobalSearch } from "@/components/shell/GlobalSearch";
import { useAuth } from "@/context/AuthContext";
import { cx } from "@/lib/format";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/feed", label: "Feed" },
  { href: "/library", label: "Library" },
  { href: "/assistant", label: "Assistant" },
] as const;

const isActive = (pathname: string, href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

/** One straight line: logo · navigation · search · create · account. Below `lg` the links fold into a menu. */
export function Navbar() {
  const router = useRouter();
  const pathname = usePathname();
  const { user, promptLogin } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => setMenuOpen(false), [pathname]);
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (event: KeyboardEvent) => event.key === "Escape" && setMenuOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  const create = () => {
    if (!user) {
      promptLogin("login");
      return;
    }
    router.push("/feed?compose=1");
  };

  return (
    <header className="sticky top-0 z-40 border-b border-stone-200 bg-paper/95 backdrop-blur supports-[backdrop-filter]:bg-paper/85">
      <div className="mx-auto flex h-16 w-full max-w-[1520px] items-center gap-2 px-3 sm:gap-4 sm:px-6">
        <button
          type="button"
          onClick={() => setMenuOpen((v) => !v)}
          className="rounded-lg p-2 text-stone-600 transition hover:bg-stone-100 hover:text-ink lg:hidden"
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
        >
          {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>

        <Link href="/" className="flex shrink-0 items-center gap-3" aria-label="Chanakya Research Commons home">
          <span aria-hidden className="relative flex h-9 w-9 items-center justify-center rounded-md bg-brand-900 font-display text-[22px] font-bold leading-none text-white">
            C
            <span className="absolute inset-x-1.5 bottom-1 h-[2px] rounded-full bg-saffron-400" />
          </span>
          <span className="hidden leading-none xl:block">
            <span className="block font-display text-[19px] text-ink">Chanakya</span>
            <span className="mt-1 block text-[12px] font-medium tracking-wide text-stone-500">Research Commons</span>
          </span>
        </Link>

        <nav aria-label="Primary" className="ml-1 hidden h-full items-stretch lg:flex">
          {NAV.map(({ href, label }) => {
            const active = isActive(pathname, href);
            return (
              <Link
                key={href}
                href={href}
                aria-current={active ? "page" : undefined}
                className={cx(
                  "relative flex items-center px-3.5 text-ui font-medium transition-colors duration-150",
                  active ? "text-ink" : "text-stone-500 hover:text-ink",
                )}
              >
                {label}
                <span aria-hidden className={cx("absolute inset-x-3.5 bottom-0 h-[3px] bg-saffron-400 transition-opacity duration-150", active ? "opacity-100" : "opacity-0")} />
              </Link>
            );
          })}
        </nav>

        <div className="flex min-w-0 flex-1 justify-end lg:justify-center">
          <GlobalSearch />
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <button
            type="button"
            onClick={create}
            className="hidden h-10 items-center gap-1.5 rounded-lg bg-brand-600 px-4 text-ui font-medium text-white transition hover:bg-brand-700 xl:inline-flex"
            aria-label="Create a post"
          >
            <Plus className="h-4 w-4" /> Create
          </button>
          <AccountMenu />
        </div>
      </div>

      {menuOpen && (
        <nav aria-label="Primary" className="animate-fade border-t border-stone-200 bg-paper px-3 pb-3 pt-2 lg:hidden">
          {NAV.map(({ href, label }) => {
            const active = isActive(pathname, href);
            return (
              <Link
                key={href}
                href={href}
                aria-current={active ? "page" : undefined}
                className={cx(
                  "flex items-center justify-between rounded-lg px-3 py-3 text-body font-medium transition",
                  active ? "bg-brand-50 text-brand-700" : "text-stone-600 hover:bg-stone-100 hover:text-ink",
                )}
              >
                {label}
                {active && <span aria-hidden className="h-2 w-2 rounded-full bg-saffron-400" />}
              </Link>
            );
          })}
          <button type="button" onClick={create} className="mt-1 flex w-full items-center gap-2 rounded-lg px-3 py-3 text-left text-body font-medium text-brand-700 hover:bg-stone-100">
            <Plus className="h-4 w-4" /> Create a post
          </button>
        </nav>
      )}
    </header>
  );
}
