import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./context/**/*.{js,ts,jsx,tsx}",
    "./lib/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Surfaces: clean cool paper. White cards on a faint blue-grey canvas.
        canvas: "#F4F6FA",
        paper: "#FFFFFF",
        sunken: "#EDF0F6",
        ink: {
          DEFAULT: "#0E1B33",
          soft: "#1B2A47",
        },
        // Neutrals (text-stone-*, border-stone-*, bg-stone-*): cool slate.
        stone: {
          50: "#F8F9FC",
          100: "#EFF2F7",
          200: "#E0E5EE",
          300: "#C7CEDC",
          400: "#97A1B6",
          500: "#69738A",
          600: "#4B556B",
          700: "#363F55",
          800: "#222B40",
          900: "#0E1B33",
        },
        // Brand: Chanakya navy. Primary actions, links, active states.
        brand: {
          50: "#EEF2FB",
          100: "#DCE5F6",
          200: "#B8C9EA",
          300: "#8CA6D8",
          400: "#5C7FC0",
          500: "#34589F",
          600: "#1E3F7D",
          700: "#16316A",
          800: "#102455",
          900: "#0A1A3F",
        },
        // Accent: marigold gold. One bright note against the navy; used sparingly.
        saffron: {
          50: "#FFF8E6",
          100: "#FDEDBF",
          200: "#F8DB86",
          300: "#F2C84F",
          400: "#EBB52A",
          500: "#C99312",
          600: "#8F6A0C",
        },
        // Integrity watchlist: muted terracotta
        terracotta: {
          50: "#FBF3EF",
          100: "#F6E4DB",
          200: "#EBC6B4",
          500: "#B9633F",
          600: "#A3522F",
          700: "#85411F",
        },
        // Breakout impact: muted sage
        sage: {
          50: "#F2F6F1",
          100: "#E1EBDE",
          200: "#C3D6BD",
          500: "#5E8A5A",
          600: "#4A7247",
          700: "#3B5B39",
        },
      },
      fontFamily: {
        // Playfair Display: headings. Outfit: everything else.
        serif: ["var(--font-serif)", "Georgia", "Cambria", "serif"],
        sans: ["var(--font-sans)", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      fontSize: {
        body: ["16px", { lineHeight: "26px" }],
        ui: ["15px", { lineHeight: "22px" }],
        meta: ["14px", { lineHeight: "20px" }],
        label: ["12px", { lineHeight: "16px" }],
        h1: ["clamp(1.75rem, 3vw, 2.25rem)", { lineHeight: "1.15" }],
        h2: ["24px", { lineHeight: "30px" }],
        h3: ["18px", { lineHeight: "26px" }],
      },
      letterSpacing: {
        eyebrow: "0.01em",
      },
      boxShadow: {
        card: "0 1px 0 rgba(14, 27, 51, 0.03)",
        lift: "0 12px 28px -14px rgba(14, 27, 51, 0.30)",
        pop: "0 20px 48px -16px rgba(14, 27, 51, 0.42), 0 4px 12px -4px rgba(14, 27, 51, 0.10)",
      },
      keyframes: {
        shimmer: {
          "100%": { transform: "translateX(100%)" },
        },
        rise: {
          "0%": { opacity: "0", transform: "translateY(6px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        fade: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        pop: {
          "0%": { opacity: "0", transform: "translateY(10px) scale(0.97)" },
          "100%": { opacity: "1", transform: "translateY(0) scale(1)" },
        },
        slidein: {
          "0%": { transform: "translateX(24px)", opacity: "0" },
          "100%": { transform: "translateX(0)", opacity: "1" },
        },
        bump: {
          "0%": { transform: "scale(1)" },
          "40%": { transform: "scale(1.35)" },
          "100%": { transform: "scale(1)" },
        },
      },
      animation: {
        rise: "rise 260ms ease-out both",
        fade: "fade 180ms ease-out both",
        pop: "pop 220ms cubic-bezier(0.22, 1, 0.36, 1) both",
        slidein: "slidein 240ms cubic-bezier(0.22, 1, 0.36, 1) both",
        bump: "bump 260ms ease-out",
      },
    },
  },
  plugins: [],
};
export default config;
